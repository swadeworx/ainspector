pref("extensions.firebug.ainspector.enableSites", false);
pref("extensions.firebug.DBG_AINSPECTOR", true);
