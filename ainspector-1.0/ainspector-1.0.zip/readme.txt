Including preferences into A11y:

1. Edit the following lines to locate openajax_a11y_all.js and logging.js in preferences-dialog.xul
  <script src="chrome://ainspector/content/utilities/logging.js"/>
  <script src="chrome://ainspector/content/openajax_a11y/openajax_a11y_all.js"/> 